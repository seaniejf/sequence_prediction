
def corpus_results(tids):
	# I had to add the nlp.get_nlp_data() method to lib/python3.x/site-packages/atom/nlp.py
	# In Vectorizer.transform, the results need to be saved somewhere, so I used a global to store the results.
	# global nlp_data
	# nlp_data = pd.concat([X, to_df(matrix, X.index, columns)], axis=1)
	# return nlp_data
	#
	# The new function only needs to return the global data. I resisted the urge to cleanup the data to minimize the
	# surgery in this file, so the caller has to do any cleanup.
	# def get_nlp_data():
	#	 return nlp_data
	#
	# Additionally, there is a bug in the Tokenizer.tranform method. There needs to be a check to make sure rows is not
	# empty before calling:   df = pd.DataFrame(rows).sort_values("frequency", ascending=False)

	corpus_data = nlp.get_nlp_data()
	corpus_data = corpus_data.loc[:, (corpus_data != 0).any(axis=0)]   # Remove rows that are all zeros
	corpus_data = corpus_data.T   # Transpose table as there are more keywords than tickets.
	corpus_data = corpus_data.rename(columns=tids)
	corpus_data.index = corpus_data.index.str.replace(r'corpus_', '', regex=True)  # remove corpus_ from index names
	if args.verbose:
		print('=' * 80)
		print(corpus_data.to_string())

	if args.verbose:
		for tid in tids.values():
			junk = corpus_data[tid].apply(lambda x: x if x != 0.0 else None)
			junk = junk.dropna()
			junk = junk.sort_values(ascending=False)
			print('=' * 80, "\n", tid)
			print(junk.to_string())

	words = corpus_data.apply(lambda x: x != 0)   # true/false matrix
	words = words.apply(lambda x: list(corpus_data.index[x.values]), axis=0)

	return words


def use_random_forest_model(c, tids):
	scores = atom.RF.predict_proba(c)
	df = pd.DataFrame(scores).T
	df['comp'] = comps
	cols = df.columns.tolist()
	df = df[cols].rename(columns=tids)
	df = df.set_index('comp')
	if args.verbose:
		print(df.to_string())

	minvalue_series = df.idxmax(axis=0)  # get the index of the value closest to the hyperplane
	words = corpus_results(tids)
	result = pd.concat([minvalue_series, words], axis=1)
	result = result.rename(columns={0: 'Component', 1: 'Keywords'})
	print(result.to_string())


def use_ridge_model(c, tids):
	# The easy way:
	# predictions = atom.Ridge.predict(c)
	# print(predictions)

	# The rewarding way:
	scores = atom.Ridge.decision_function(c)

	# This dataframe reports how each component scored.  It might be helpful to see what 2nd or 3rd choice was.
	df = pd.DataFrame(scores).T
	df = df.rename(columns=tids)
	df['comp'] = comps
	df = df.set_index('comp')
	if args.verbose:
		print('=' * 80)
		print(df.to_string())

	# This dataframe generates our predictions.
	minvalue_series = df.idxmax(axis=0)

	# This dataframe reports what words were chosen and their relations to the component.
	words = corpus_results(tids)

	# This dataframe puts the predictions and words together.
	results = pd.concat([minvalue_series, words], axis=1)
	results = results.rename(columns={0: 'Component', 1: 'Keywords'})
	if args.verbose:
		print('=' * 80)
		print(results.style.set_properties(**{'text-align': 'left'}).to_string())

	return results


def process_new_data(filename):
	global atom

	c, t = get_corpus(filename)
	# print(json.dumps(t, indent=4), json.dumps(c, indent=4))
	ticket_ids = {}
	generation = []
	for idx in range(0, len(c)):
		key, gen, summary = t[idx].split('|', 2)  # Summary might include '|', so limit to first 2.
		ticket_ids[idx] = key   # Use a dictionary for pandas dataframe columns renaming.
		generation.append(gen)

	results = use_ridge_model(c, ticket_ids)
	#use_random_forest_model(c, ticket_ids)

	idx=0
	for tix,row in results.iterrows():
		comp = row[0]
		gen = generation[idx]
		keywords = row[1]
		idx += 1
		if args.add_comment:
			# Just log a suggestion in comments
			jira.issue_add_comment(tix, f"{comp}|{gen}|{keywords}")
		elif args.update:
			update_component(tix, gen, comp)
		else:
			# make the caller explicitly set a flag to actual change a ticket, otherwise just print:
			print(f"{idx}|{comp}|{gen}|{keywords}")

##################################################
## Main
##################################################

parser = argparse.ArgumentParser(
	prog=__file__,
	formatter_class=argparse.RawDescriptionHelpFormatter,
	epilog=textwrap.dedent(f'''\
		{__file__} -gu
		'''))
parser.add_argument("-a", "--add_comment", action="store_true", default=False, help="add results in ticket comments")
parser.add_argument("-c", "--config", action="store", dest="config", help="config file to use (json format)")
parser.add_argument("-g", "--get_data", action="store_true", default=False, help="query for new tickets and guess component")
parser.add_argument("-q", "--query_results", action="store", dest="query_results", help="use for query results")
parser.add_argument("-t", "--training", action="store_true", default=False, help="collect resolved ticket data (takes long time)")
parser.add_argument("-u", "--update", action="store_true", default=False, help="update component")
parser.add_argument("-v", "--verbose", action="store_true", default=False, help="printcorpus and comp data")
args = parser.parse_args()


model_data=os.path.join(chu.cache_dir, 'model.data')
sanitize_components()
np.set_printoptions(threshold=np.inf)

tickets = {}

if args.training:
	try:
		os.remove(model_data)
	except FileNotFoundError:
		pass
	get_training_data()

try:
	atom = ATOMLoader(model_data)
except FileNotFoundError:
	atom = atomizer()

if args.get_data:
	jira = chu.connect_to_jira()
	jql = f"filter = {chu.project.name}_Guess_Component"
	chu.get_jira_data(jql, chu.def_data_file, fields=ticket_fields)

if not args.query_results:
	args.query_results = chu.def_data_file

issues = chu.read_json(args.query_results)

if issues['total'] > 0:
	process_new_data(args.query_results)
else:
	print("no issues found")
