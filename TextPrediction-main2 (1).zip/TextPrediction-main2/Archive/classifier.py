#!/usr/bin/env python3
#
# https://towardsdatascience.com/from-raw-text-to-model-prediction-in-under-30-lines-of-python-32133d853407
#
# atom-ml v5.2
# https://tvdboom.github.io/ATOM/v5.2/examples/nlp/
#
# Work flow:
# 1. Write a python script to format data into a Pandas DataFrame, where each row is the text to use with a corresponding class:
#   Currently, the idx field is an index into an array: ["dog", "cat"], but it will be textual.
#   { "txt": "Labrador Retriever blah blah blah", "idx": "dog" }
#   { "txt": "Calico blah blah blah", "idx": "cat"}
#   If you copy demo.py to pets.py (and make any necessary adaptations), it will write a pets_training.json
#
# 2. To build the model and make predictions, run "classifier.py -f pets -m -p"
#
# 3. Modify pets.py to do whatever you want with the results.
#
# The steps could be combined into a single script, but I wanted to keep formatting data to be separate from the model so that
# classifier.py could be reused on any correctly formatted data.  Additionally, atom-ml has many modules and takes seconds to load.
#

import os
import sys
import argparse
import textwrap
import json
import numpy as np
import pandas as pd
from atom import ATOMClassifier, ATOMLoader


def read_json(fname):
    with open(fname, 'r', encoding='utf-8') as f:
        data = json.load(f)

    # The predictor expects the corpus to be an array of arrays.
    txt = np.array(data['txt']).reshape(-1, 1)

    # We have y for training data, but not for new data.
    idx = []
    if 'idx' in data:
        idx = data['idx']

    return data['classes'], txt, idx


def atomizer():
    # Initialize atom
    atom = ATOMClassifier(corpus, target, index=True, test_size=0.2, verbose=2, random_state=1)

    # encode numbers as numerical values instead of strings "1" becomes 1
    atom.clean()

    # Clean the documents from noise (emails, numbers, etc...)
    atom.textclean()

    # Convert the strings to a sequence of words. bigrams are 2 words found adjacent, trigrams=3, quadgrams=4
    atom.tokenize(bigram_freq=250, trigram_freq=150, quadgram_freq=100)

    # Normalize the text to a predefined standard.  Lemmatization:   The lemme (root word) of 'better' is 'good'.
    atom.textnormalize(stopwords="english", lemmatize=True)

    # As a last step before modelling, convert the words to vector
    atom.vectorize(strategy="tfidf")  # Term Frequency - Inverse Document Frequency.

    # Train the model
    # atom.run(metric="f1_weighted")  # Runs every model, takes hours.
    atom.run(models=["RF", "Ridge"], metric="f1_weighted")  # Just 2 good models.

    # Print model results.
    print(atom.evaluate())
    atom.save(model_file)


def predictor():
    # Load the model
    atom = ATOMLoader(model_file)

    # Easy way.  I'll cover the hard way later.
    predictions = atom.Ridge.predict(corpus)

    df = predictions.to_frame()
    df['predtxt'] = df['predict'].map(lambda x: classes[x] if x < len(classes) else 'Unknown')
    df['txt'] = corpus
    print(df.to_string())


##################################################
# Main
##################################################

parser = argparse.ArgumentParser(
    prog=__file__,
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent(f'''\
        {__file__} -f demo -m   # to force rebuild of the model.
        '''))

parser.add_argument("-f", "--file-prefix", action="store", help="file prefix")
parser.add_argument("-m", "--model", action="store_true", default=False, help="build model with existing data")
parser.add_argument("-v", "--verbose", action="store_true", default=False, help="printcorpus and comp data")
args = parser.parse_args()

if not args.file_prefix:
    print("Need file_prefix")
    sys.exit(-1)

training_data_file = f"{args.file_prefix}_training.json"  # Data to train the model.
classify_data_file = f"{args.file_prefix}_classify.json"  # Data that we want to classify.
predictions_file = f"{args.file_prefix}_predictions.json"  # The results of the classification.
model_file = f"{args.file_prefix}.model"  # The data model

classes, corpus, target = read_json(training_data_file)

if args.model or not os.path.exists(model_file):
    atomizer()
predictor()
