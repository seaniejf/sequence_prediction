#!/usr/bin/env python3

import numpy as np
from atom import ATOMClassifier
from sklearn.datasets import fetch_20newsgroups

# Use only a subset of the available topics for faster processing
X_text, y_text = fetch_20newsgroups(
    return_X_y=True,
    categories=[
        'sci.med',
        'comp.windows.x',
        'misc.forsale',
        'rec.autos',
    ],
    shuffle=True,
    random_state=1,
)
X_text = np.array(X_text).reshape(-1, 1)
print("X_text:", X_text, "\ny_text:", y_text)
atom = ATOMClassifier(X_text, y_text, index=True, test_size=0.3, verbose=2, random_state=1)

# Clean the documents from noise (emails, numbers, etc...)
atom.textclean()

# Convert the strings to a sequence of words
atom.tokenize()

# Normalize the text to a predefined standard
atom.textnormalize(stopwords="english", lemmatize=True)

# Create the bigrams using the tokenizer
atom.tokenize(bigram_freq=215)

# As a last step before modelling, convert the words to vectors
atom.vectorize(strategy="tfidf")

# Train the model
atom.run(models=["RF","Ridge"], metric="f1_weighted")

atom.evaluate()