#!/usr/bin/env python3
# https://towardsdatascience.com/from-raw-text-to-model-prediction-in-under-30-lines-of-python-32133d853407
#
# atom-ml v5.2
# https://tvdboom.github.io/ATOM/v5.2/examples/nlp/

import json
import argparse
import textwrap
import numpy as np
import pandas as pd
from sklearn.datasets import fetch_20newsgroups

newsgroups = ['alt.atheism', 'sci.med', 'comp.windows.x', 'misc.forsale', 'rec.autos']

def get_sample_data():
    # Load the dataset (get only 5 categories);
    # newsgroup_post_txt is an array of the text of the newsgroup posts
    # newsgroup_name_idx is an array of the indices of the newsgroup in the categories, i.e. comp.windows.x = 2 (base 0).
    newsgroup_post_txt, newsgroup_name_idx = fetch_20newsgroups(
        return_X_y=True,
        categories=newsgroups,
        shuffle=True,
        random_state=1
    )

    # The atom-ml example feeds X, y into ATOMClassifier and calls the predictor.
    # I want to demonstrate saving the model to show that it can be reused to make predictions with new data in json format.
    length = int(len(newsgroup_post_txt) * 0.8)  # split our sample data 80/20.

    # Use 80% of the data to build the model.
    txt = newsgroup_post_txt[:length]
    idx = newsgroup_name_idx[:length].tolist()
    data = { "classes": newsgroups, "txt": txt, "idx": idx }

    # Need to include categories in the training data file, because they can't be modified after the model is built.
    with open(training_data_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)

    # Use 20% to demonstrate the predictor after reloading the model.
    txt = newsgroup_post_txt[length:]
    idx = newsgroup_name_idx[length:].tolist()  # New data won't have idx, but we will use it to compare actuals to predictions.
    data = { "classes": newsgroups, "txt": txt, "idx": idx }

    with open(testing_data_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4)

def check_results(preds):
    # Now, we can compare the predicted results with the actual targets.
    __, original_cats = read_json(testing_data_file, read_y=True)
    df = preds.to_frame()
    with open(predictions_file, 'r', encoding='ascii') as f:
        data = json.load(f)

    # Let's map the index to the category name.
    df['predtxt'] = df['predict'].map(lambda x: newsgroups[x] if x < len(newsgroups) else 'Unknown')

    # Add the original categories to the frame.
    df['targets'] = original_cats

    # Let's map the index to the category name.
    df['origtxt'] = df['targets'].map(lambda x: newsgroups[x] if x < len(newsgroups) else 'Unknown')

    # Add a column comparing the predictor's value to the orginal categories.
    df['compare'] = df['predict'] == df['targets']

    # Get an overall score of the predictor.
    print("prediction accuracy:", df['compare'].mean())

    # Dump the frame for inspection.
    print(df.to_string())

    # Show if the False comparisons are favoring a particular category or having trouble with a specific source category.


def read_json(fname, read_y=False):
    # This function needs to handle a json file with no y data.
    df = pd.read_json(fname, orient='records')

    # The predictor expects the corpus to be an array of arrays.
    txt = np.array(df['txt'].to_numpy(dtype=np.ndarray)).reshape(-1, 1)

    # We have y for training data, but not for new data.
    if read_y:
        idx = df['idx'].to_numpy(dtype=np.ndarray)
    else:
        idx = []
    return txt, idx


##################################################
# Main
##################################################

parser = argparse.ArgumentParser(
    prog=__file__,
    formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog=textwrap.dedent(f'''\
        {__file__} -gu
        '''))

parser.add_argument("-f", "--file_prefix", action="store", default="demo", help="rebuild model with existing data")
parser.add_argument("-g", "--get_sample_data", action="store_true", default=False, help="get sample data")
parser.add_argument("-p", "--predictions", action="store_true", default=False, help="check the results of predictions")
parser.add_argument("-v", "--verbose", action="store_true", default=False, help="print corpus and comp data")
args = parser.parse_args()

training_data_file = f"{args.file_prefix}_training.json"  # Data to train the model.
testing_data_file = f"{args.file_prefix}_classify.json"  # Data that we want to classify.
predictions_file = f"{args.file_prefix}_predictions.json"
model_file = f"{args.file_prefix}.model"  # The data model

if args.get_sample_data:
    get_sample_data()

if args.predictions:
    check_results(pre)

