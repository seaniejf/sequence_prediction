#
# coverage run -m unittest discover -s tests/
# coverage report -m

import os
import json
import unittest
from textractor import Textractor
from textractor import BuildDocCache
from textractor import ClassifyDocs

TEST_LIB = "tests/test_lib"

class TestTextractor(unittest.TestCase):
    def setUp(self):
        self.textractor = Textractor()

    def test_remove_whitespace_and_numbers(self):
        input_string = "Hello,    world! 123"
        expected_output = "Hello, world!"
        self.assertEqual(self.textractor._remove_whitespace_and_numbers(input_string), expected_output)

    def test_extract_text_from_pdf(self):
        pdf_path = f"{TEST_LIB}/example-small.pdf"
        expected_output = "This is an example PDF file."
        self.assertEqual(self.textractor.extract_text_from_pdf(pdf_path), expected_output)

    def test_textraction(self):
        file_path = f"{TEST_LIB}/example-small.txt"
        expected_output = "This is an example text file."
        self.assertEqual(self.textractor.textraction(file_path), expected_output)

    def test_write_text(self):
        dst = "output.txt"
        text = "This is an example text file."*10
        self.textractor.write_text(dst, text)
        self.assertTrue(os.path.exists(dst))
        with open(dst, "r", encoding="utf-8") as f:
            self.assertEqual(f.read(), text)

class TestBuildDocCache(unittest.TestCase):
    def setUp(self):
        self.build_doc_cache = BuildDocCache()

    def test_build_training_cache(self):
        training_lib = f"{TEST_LIB}"
        self.build_doc_cache.build_training_cache(training_lib)
        self.assertTrue(os.path.exists(self.build_doc_cache.training_file))

    def test_build_training_cache_file(self):
        self.build_doc_cache.build_training_cache_file()
        self.assertTrue(os.path.exists(self.build_doc_cache.training_file))

    def test_calculate_md5(self):
        file_path = f"{TEST_LIB}/example.txt"
        expected_output = "ee9ede84d308ec54ca10c49a82d0c92e"
        self.assertEqual(self.build_doc_cache.calculate_md5(file_path), expected_output)

    def test_add_one_document(self):
        file_path = f"{TEST_LIB}/example.txt"
        dest = f"{TEST_LIB}"
        self.build_doc_cache.add_one_document(file_path, dest)
        self.assertTrue(os.path.exists(dest))
        with open(f"{dest}/ee9ede84d308ec54ca10c49a82d0c92e.txt", "r",encoding="utf-8") as f:
            self.assertEqual(json.load(f), {"txt": "This is an example text file."})

class TestClassifyDocs(unittest.TestCase):
    def setUp(self):
        self.classify_docs = ClassifyDocs()

    def test_add_one_document(self):
        file_path = f"{TEST_LIB}/example.txt"
        self.classify_docs.add_one_document(file_path)
        self.assertEqual(self.classify_docs.docset, [{"id": file_path, "txt": "This is an example text file."}])

    def test_add_all_documents(self):
        root = f"{TEST_LIB}"
        self.classify_docs.add_all_documents(root)
        self.assertEqual(self.classify_docs.docset, [{"id": f"{TEST_LIB}/doc1.txt", "txt": "This is an example text file."}, {"id": f"{TEST_LIB}/documents/doc2.txt", "txt": "This is another example text."}])

    def test_handler(self):
        source = f"{TEST_LIB}"
        self.classify_docs.handler(source)
        self.assertEqual(self.classify_docs.docset, [{"id": source, "txt": "This is an example text file."*10}])

    def test_get_predict_file(self):
        self.assertEqual(self.classify_docs.get_predict_file(), f"{TEST_LIB}/predict.json")

    def test_write_predict_File(self):
        self.classify_docs.write_predict_File()
        self.assertTrue(os.path.exists(self.classify_docs.predict_file))
        with open(self.classify_docs.predict_file, "r", encoding="utf-8") as f:
            self.assertEqual(json.load(f), self.classify_docs.docset)

if __name__ == "__main__":
    unittest.main()
